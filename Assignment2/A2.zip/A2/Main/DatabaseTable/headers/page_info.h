#ifndef PAGEINFO_H
#define PAGEINFO_H
#include <stddef.h>
struct pageInfo
{
	int currPosition;
};
#endif