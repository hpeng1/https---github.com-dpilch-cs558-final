
// this lists all of the different page types
enum MyDB_PageType {RegularPage, DirectoryPage};
