

/****************************************************
** COPYRIGHT 2016, Chris Jermaine, Rice University **
**                                                 **
** The MyDB Database System, COMP 530              **
** Note that this file contains SOLUTION CODE for  **
** A3.  You should not be looking at this file     **
** unless you have completed A3!                   **
****************************************************/


#ifndef SORT_C
#define SORT_C

#include <queue>
#include "MyDB_PageReaderWriter.h"
#include "MyDB_TableRecIterator.h"
#include "MyDB_TableRecIteratorAlt.h"
#include "MyDB_TableReaderWriter.h"
#include "IteratorComparator.h"
#include "Sorting.h"

using namespace std;

void mergeIntoFile (MyDB_TableReaderWriter &sortIntoMe, vector <MyDB_RecordIteratorAltPtr> &mergeUs, 
	function <bool ()> comparator, MyDB_RecordPtr lhs, MyDB_RecordPtr rhs) {

	// create the comparator and the priority queue
	IteratorComparator temp (comparator, lhs, rhs);
	priority_queue <MyDB_RecordIteratorAltPtr, vector <MyDB_RecordIteratorAltPtr>, IteratorComparator> pq (temp);

	// load up the set
	for (MyDB_RecordIteratorAltPtr m : mergeUs) {
		if (m->advance ()) {
			pq.push (m);
		}
	}

	// and write everyone out
	int counter = 0;
	while (pq.size () != 0) {

		// write the dude to the output
		auto myIter = pq.top ();
		myIter->getCurrent (lhs);
		sortIntoMe.append (lhs);
		counter++;

		// remove from the q
		pq.pop ();

		// re-insert
		if (myIter->advance ()) {
			pq.push (myIter);
		}
	}
}

void appendRecord (MyDB_PageReaderWriter &curPage, vector <MyDB_PageReaderWriter> &returnVal, 
	MyDB_RecordPtr appendMe, MyDB_BufferManagerPtr parent) {

	// try to append to the current page
	if (!curPage.append (appendMe)) {

		// if we cannot, then add a new one to the output vector
		returnVal.push_back (curPage);
		MyDB_PageReaderWriter temp (*parent);
		temp.append (appendMe);
		curPage = temp;
	}
}

vector <MyDB_PageReaderWriter> mergeIntoList (MyDB_BufferManagerPtr parent, MyDB_RecordIteratorAltPtr leftIter, 
	MyDB_RecordIteratorAltPtr rightIter, function <bool ()> comparator, MyDB_RecordPtr lhs, MyDB_RecordPtr rhs) {
	
	vector <MyDB_PageReaderWriter> returnVal;
	MyDB_PageReaderWriter curPage (*parent);
	bool lhsLoaded = false, rhsLoaded = false;

	// if one of the runs is empty, get outta here
	if (!leftIter->advance ()) {
		while (rightIter->advance ()) {
			rightIter->getCurrent (rhs);
			appendRecord (curPage, returnVal, rhs, parent);
		}
	} else if (!rightIter->advance ()) {
		while (leftIter->advance ()) {
			leftIter->getCurrent (lhs);
			appendRecord (curPage, returnVal, lhs, parent);
		}
	} else {
		while (true) {
	
			// get the two records

			// here's a bit of an optimization... if one of the records is loaded, don't re-load
			if (!lhsLoaded) {
				leftIter->getCurrent (lhs);
				lhsLoaded = true;
			}

			if (!rhsLoaded) {
				rightIter->getCurrent (rhs);		
				rhsLoaded = true;
			}
	
			// see if the lhs is less
			if (comparator ()) {
				appendRecord (curPage, returnVal, lhs, parent);
				lhsLoaded = false;

				// deal with the case where we have to append all of the right records to the output
				if (!leftIter->advance ()) {
					appendRecord (curPage, returnVal, rhs, parent);
					while (rightIter->advance ()) {
						rightIter->getCurrent (rhs);
						appendRecord (curPage, returnVal, rhs, parent);
					}
					break;
				}
			} else {
				appendRecord (curPage, returnVal, rhs, parent);
				rhsLoaded = false;

				// deal with the ase where we have to append all of the right records to the output
				if (!rightIter->advance ()) {
					appendRecord (curPage, returnVal, lhs, parent);
					while (leftIter->advance ()) {
						leftIter->getCurrent (lhs);
						appendRecord (curPage, returnVal, lhs, parent);
					}
					break;
				}
			}
		}
	}
	
	// remember the current page
	returnVal.push_back (curPage);
	
	// outta here!
	return returnVal;
}
	
void sort (int runSize, MyDB_TableReaderWriter &sortMe, MyDB_TableReaderWriter &sortIntoMe, 
	function <bool ()> comparator, MyDB_RecordPtr lhs, MyDB_RecordPtr rhs) {

	// this is the list of all of the pages in the file
	vector <vector<MyDB_PageReaderWriter>> allPages;

	// this is the pages making up the current run
	vector <vector<MyDB_PageReaderWriter>> pagesToSort;

	// this is the list of all of the iterators, with one for each run
	vector <MyDB_RecordIteratorAltPtr> runIters;
	
	int mySize = 0;

	// process the file 
	for (int i = 0; i < sortMe.getNumPages (); i++) {

		// add this next page
		vector <MyDB_PageReaderWriter> run;
		run.push_back (*(sortMe[i].sort (comparator, lhs, rhs)));
		pagesToSort.push_back (run);

		// if we are not done reading this run, go on to the next one
		if (pagesToSort.size () != runSize && i != sortMe.getNumPages () - 1)
			continue;

		// while we don't have a single sorted list
		while (pagesToSort.size () > 1) {
			
			// the new version of the pages to sort vector
			vector <vector<MyDB_PageReaderWriter>> newPagesToSort;
	
			// repeatedly merge the last two pages
			while (pagesToSort.size () > 0) {
	
				// if there is one run, then just add it
				if (pagesToSort.size () == 1) {
					newPagesToSort.push_back (pagesToSort.back ());
					pagesToSort.pop_back ();
					continue;
				}
	
				// get the next two runs
				vector<MyDB_PageReaderWriter> runOne = pagesToSort.back ();
				pagesToSort.pop_back ();
				vector<MyDB_PageReaderWriter> runTwo = pagesToSort.back ();
				pagesToSort.pop_back ();
		
				// merge them
				newPagesToSort.push_back (mergeIntoList (sortMe.getBufferMgr (), getIteratorAlt (runOne), 
					getIteratorAlt (runTwo), comparator, lhs, rhs));
			}
	
			pagesToSort = newPagesToSort;
		}

		// now we have a single list, so create an iterator for it
		mySize += pagesToSort[0].size ();
		runIters.push_back (getIteratorAlt (pagesToSort[0]));

		// and start over on the next run
		pagesToSort.clear ();
	}
	
	// and now, we are ready to merge everything
	mergeIntoFile (sortIntoMe, runIters, comparator, lhs, rhs);
}

#endif
